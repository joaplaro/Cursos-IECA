
#
# ��Ojo!! 
# Si al ejecutar este script te aparecen mensajes de 'ERROR', leete el fichero 'LEEME.odt' ubicado en la carpeta de los datos del Censo. 


#Paso 1 - Cargamos librer�as necesarias
library(tidyverse)
options(scipen=999) 

#Paso 2 - Cargamos los microdatos que proporciona el INE. Se trata de ficheros planos sin separaciones.
#         Los tenemos ubicados en la misma carpeta que el c�digo R
DATOS_HP  <- read.table(paste0(getwd(),'/DATOS_HP.TXT'),sep=';',colClasses="character") 
DATOS_VE  <- read.table(paste0(getwd(),'/DATOS_VE.TXT'),sep=';',colClasses="character")  

#Paso 3 - Incorporamos los dise�os de registro
DISE_HP <- read.table(paste0(getwd(),'/DISE_HP.TXT'), sep=";",header=TRUE,colClasses="character")
DISE_VE <- read.table(paste0(getwd(),'/DISE_VE.TXT'), sep=";",header=TRUE,colClasses="character") 

#Paso 4 - Finalmente, usamos los dise�os de registro para divivir cada registro en los campos que corresponda
DATOS_HP  <- separate(DATOS_HP, col = V1, into = DISE_HP$CODVAR, sep = as.numeric(DISE_HP$FIN), remove = TRUE) %>% mutate(FACTOR=as.numeric(FACTOR)) 
DATOS_VE  <- separate(DATOS_VE, col = V1, into = DISE_VE$CODVAR, sep = as.numeric(DISE_VE$FIN), remove = TRUE) %>% mutate(FACTOR=as.numeric(FACTOR))




